/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcialresuelto;

/**
 *
 * @author marce
 */
public class Ave extends Animal implements Vacunable{
    
    private double envergaduraAlas;

    public Ave(String nombre, int edad, double peso, double envergaduraAlas) {
        super(nombre, edad, peso);
        this.envergaduraAlas = envergaduraAlas;
    }

    @Override
    public String toString() {
        return "Ave{" + "envergaduraAlas=" + envergaduraAlas + '}';
    }

    @Override
    public void vacunar() {
        System.out.println("Soy el ave " + nombre + " y me vacuno");
    }
    
    
    
}
