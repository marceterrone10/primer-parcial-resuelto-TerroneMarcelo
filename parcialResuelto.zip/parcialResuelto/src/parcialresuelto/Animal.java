package parcialresuelto;

import java.util.Objects;


public abstract class Animal {
    protected String nombre;
    protected int edad;
    protected double peso;

    public Animal(String nombre, int edad, double peso) {
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
    }

    public String getNombre() {
        return nombre;
    }
    
  
    @Override
    public boolean equals(Object o){
        if(this==o){
            return true;
        }
        if(o==null || o.getClass() != this.getClass()){
            return false;
        }
        Animal animal = (Animal) o;
        return nombre.equals(animal.nombre) && edad == animal.edad;
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre, edad);
    }

    @Override
    public abstract String toString();
    
    
    
}
