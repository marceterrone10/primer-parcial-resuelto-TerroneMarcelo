package parcialresuelto;

import java.util.ArrayList;


public class Zoologico {
    
    ArrayList<Animal> animales;

    public Zoologico() {
        animales = new ArrayList<>();
    }
    
    public void verificarAnimalRepetido(Animal a){
        if(animales.contains(a)){
            throw new animalRepetidoException();
        }
    }
    
    public void agregarAnimal(Animal a){
        verificarAnimalRepetido(a);
        if(a!=null){
            animales.add(a);
        }
    }
    
    public void mostrarAnimales(){
        for(Animal a: animales){
            System.out.println(a.toString());
        }
    }
    
    public void vacunarAnimales(){
        for (Animal a: animales){
            if(a instanceof Vacunable vacunable){
                vacunable.vacunar();
            }
            else {
                System.out.println(a.getNombre() + " no es vacunable");
            }
        }
    }
    
    
    
}
