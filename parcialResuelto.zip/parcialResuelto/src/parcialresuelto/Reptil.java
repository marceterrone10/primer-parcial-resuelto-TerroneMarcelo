/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcialresuelto;

/**
 *
 * @author marce
 */
public class Reptil extends Animal{
    
    private String tipoEscama;
    private String regTempetarura;

    public Reptil(String nombre, int edad, double peso, String tipoEscama, String regTempetarura) {
        super(nombre, edad, peso);
        this.tipoEscama = tipoEscama;
        this.regTempetarura = regTempetarura;
    }

    @Override
    public String toString() {
        return "Reptil{" + "tipoEscama=" + tipoEscama + ", regTempetarura=" + regTempetarura + '}';
    }


    
    
}
