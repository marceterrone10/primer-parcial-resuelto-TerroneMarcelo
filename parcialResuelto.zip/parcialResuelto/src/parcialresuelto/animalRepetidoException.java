/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcialresuelto;

/**
 *
 * @author marce
 */
public class animalRepetidoException extends RuntimeException {
    private static final String MESSAGE = "El animal ya se encuentra en la lista";
    
    
    public animalRepetidoException() {
        super(MESSAGE);
        
    }
    
}
