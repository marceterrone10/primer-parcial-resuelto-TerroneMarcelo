/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package parcialresuelto;

/**
 *
 * @author marce
 */
public class Mamifero extends Animal implements Vacunable{
    private TipoDieta tipoDieta;

    public Mamifero(String nombre, int edad, double peso, TipoDieta tipoDieta) {
        super(nombre, edad, peso);
        this.tipoDieta = tipoDieta;
    }

    @Override
    public String toString() {
        return "Mamifero{" + "peso=" + peso + ", TipoDieta=" + tipoDieta + '}';
    }

    @Override
    public void vacunar() {
        System.out.println("Soy el mamifero " + nombre + " y me vacuno");
    }
    
    
}
