package parcialresuelto;


public class Test {


    public static void main(String[] args) {
        
        Zoologico zoo = new Zoologico();
        
        Mamifero m1 = new Mamifero("Marcezika", 20, 90.0, TipoDieta.CARNIVORO);
        Mamifero m2 = new Mamifero("Tomi", 2, 30, TipoDieta.HERBIVORO);
        Mamifero m3 = new Mamifero("Mike Tyson", 40, 65.2, TipoDieta.OMNIVORO);
        Mamifero m4 = m2;
        
        Ave a1 = new Ave("Pepe Itaca", 4, 5.600, 54.7);
        Ave a2 = new Ave("Rey", 2, 2.2, 54.7);
        Ave a3 = a2;
        
        Reptil r1 = new Reptil("Loco", 10, 15.5, "Queratinosa", "ectotermia");
        Reptil r2 = new Reptil("Preto", 3, 6, "Queratinosa", "niggertermia");
        Reptil r3 = r1;
        
        try{
            zoo.agregarAnimal(m1);
            System.out.println("Se agrego correctamente el animal");
        
        }catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }
        try{
            zoo.agregarAnimal(m2);
            System.out.println("Se agrego correctamente el animal");
        
        }catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }
        try{
            zoo.agregarAnimal(m3);
            System.out.println("Se agrego correctamente el animal");
        
        }catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }
        try{
            zoo.agregarAnimal(m4); //tiene que tirar exception
            System.out.println("Se agrego correctamente el animal");
        
        }catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }
        
        System.out.println("--------------------------------------------------");
        
        try{
            zoo.agregarAnimal(a1);
            System.out.println("Se agrego correctamente el animal");
        
        }catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }
        try{
            zoo.agregarAnimal(a2);
            System.out.println("Se agrego correctamente el animal");
        
        }catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }        
        try{
            zoo.agregarAnimal(a3);
            System.out.println("Se agrego correctamente el animal");
        
        }catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }   
        
        System.out.println("---------------------------------------------------");
        
        try{
            zoo.agregarAnimal(r1);
            System.out.println("Se agrego correctamente el animal");
        
        }catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }
        try{
            zoo.agregarAnimal(r2);
            System.out.println("Se agrego correctamente el animal");
        
        }catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }
        try{
            zoo.agregarAnimal(r3);
            System.out.println("Se agrego correctamente el animal");
        
        }catch(animalRepetidoException e){
            System.out.println(e.getMessage());
        }
        
        System.out.println("---------------------------------------------------");
        
        zoo.mostrarAnimales();
        
        System.out.println("----------------------------------------------------");
        
        zoo.vacunarAnimales();
        
    }
    
}
